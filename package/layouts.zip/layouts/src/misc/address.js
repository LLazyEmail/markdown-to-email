const config = require('../config');

module.exports = `<strong>Our mailing address is:</strong>
<br>
${config.mailingAddress}`;

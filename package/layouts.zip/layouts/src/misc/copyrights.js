module.exports = `<em>Copyright © ${new Date().getFullYear()} Hacker Noon. All rights reserved.</em>`;

// import Address from './address';
// import Copyright from './copyrights';
// import NewsletterSponsorshipLink from './newsletter-sponsorship-link';
// import Unsubscribe from './unsubscribe';

// console.log(Address);

// export default {
//     Address, Copyright, NewsletterSponsorshipLink, Unsubscribe
// } ;

import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
ReactDOM.render(<App />, document.querySelector('#root'));
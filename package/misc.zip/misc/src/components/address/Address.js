import React from 'react';

const Address = () => (
  <div>
    <strong>Our mailing address is:</strong>
    <br />
    PO Box 2206, Edwards CO, 81632, U.S.A.
  </div>
);

// class Address extends React.Component {
//   render() {
//     return (
//       <div>
//         <strong>Our mailing address is:</strong>
//         <br />
//         PO Box 2206, Edwards CO, 81632, U.S.A.
//       </div>
//     )
//   }
// }

export default Address;

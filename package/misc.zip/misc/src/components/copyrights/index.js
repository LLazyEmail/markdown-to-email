import Copyright from './Copyrights';

export default Copyright;

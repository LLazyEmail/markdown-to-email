export const config = {
  contact: 'https://sponsor.hackernoon.com/newsletter?ref=noonifications.tech',
};
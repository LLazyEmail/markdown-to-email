import NewsletterSponsorshipLink from './Newsletter';

export default NewsletterSponsorshipLink;

import Strong from './Strong';

export default Strong;

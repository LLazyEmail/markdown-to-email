export const styles = {
  strong: {
    fontWeight: 'bolder'
  }
};
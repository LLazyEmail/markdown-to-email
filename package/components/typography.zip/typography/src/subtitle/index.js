import SubTitle from './Subtitle';

export default SubTitle;

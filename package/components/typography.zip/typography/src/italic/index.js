import Italic from './Italic';

export default Italic;

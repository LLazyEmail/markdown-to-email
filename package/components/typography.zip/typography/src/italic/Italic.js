import React from 'react';

const Italic = ({ children }) => (
  <i>
    {children}
  </i>
);

export default Italic;

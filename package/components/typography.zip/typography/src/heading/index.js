import Heading from './Heading';

export default Heading;

import MainTitle from './MainTitle';

export default MainTitle;

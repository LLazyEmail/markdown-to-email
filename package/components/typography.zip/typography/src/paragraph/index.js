import Paragraph from './Paragraph';

export default Paragraph;

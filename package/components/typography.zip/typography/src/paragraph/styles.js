export const styles = {
  ltr: {
    textAlign: 'justify',
  },
  spanSize: {
    fontSize: '16px',
  },
  spanFont: {
    fontFamily: 'trebuchet ms,lucida grande,lucida sans unicode,lucida sans,tahoma,sans-serif',
  },
};

1. install rollup and stuff
2. export components into main index.js
3. use babel with build and see how it goes
4. test publish 

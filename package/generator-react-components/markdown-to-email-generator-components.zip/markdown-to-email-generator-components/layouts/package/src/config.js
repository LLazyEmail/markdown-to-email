const config = {
  contact: "https://sponsor.hackernoon.com/contact",
  mailingAddress: "PO Box 2206, Edwards CO, 81632, U.S.A.",
  unsubscribe: '#'
}

module.exports = config;
module.exports= `<Heading>{content}</Heading>`;

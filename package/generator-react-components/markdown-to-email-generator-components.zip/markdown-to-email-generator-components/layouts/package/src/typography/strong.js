module.exports = `<Strong>{content}</Strong>`;

module.exports = `<Paragraph>{content}</Paragraph>`;

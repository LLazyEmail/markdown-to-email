module.exports = `<SubTitle>{content}</SubTitle>`;

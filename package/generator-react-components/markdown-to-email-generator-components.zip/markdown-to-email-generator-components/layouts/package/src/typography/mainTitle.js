module.exports= `<MainTitle>{content}</MainTitle>`;

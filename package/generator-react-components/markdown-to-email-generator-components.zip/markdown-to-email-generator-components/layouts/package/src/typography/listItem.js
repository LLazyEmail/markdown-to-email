module.exports = `<ListItem>{content}</ListItem>`;

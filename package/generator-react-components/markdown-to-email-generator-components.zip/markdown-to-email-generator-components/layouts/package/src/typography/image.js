module.exports = `      <Image
        href="{}"
        src="https://raw.githubusercontent.com/atherdon/newsletters/master/archive/img/memes/6.jpg"
        alt="{}"
      />`;

module.exports = `<Link href="{href}" />`;

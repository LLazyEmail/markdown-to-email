module.exports = `<Copyright />`;

const config = require('../config');

module.exports = `<Unsubscribe />`;

const config = require('../config');

module.exports = `<Address />
${config.mailingAddress}`;

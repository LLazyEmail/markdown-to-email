const config = require('../config');

module.exports = `<NewsletterSponsorshipLink />`;

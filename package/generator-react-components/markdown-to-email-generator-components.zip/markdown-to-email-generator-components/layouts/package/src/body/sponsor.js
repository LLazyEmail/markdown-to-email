module.exports = `<Sponsor param="{content}" />`;

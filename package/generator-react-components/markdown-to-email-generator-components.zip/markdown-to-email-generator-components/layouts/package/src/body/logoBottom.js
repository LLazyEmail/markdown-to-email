module.exports = `<Logo />`;

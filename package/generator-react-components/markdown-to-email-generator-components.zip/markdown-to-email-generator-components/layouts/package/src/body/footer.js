const copyrights = require("../misc/copyrights");
const address = require("../misc/address");
const unsubscribe = require("../misc/unsubscribe");
const newsletterSponsorshipLink = require("../misc/newsletter-sponsorship-link");

module.exports = `<Footer>{children}</Footer>`;

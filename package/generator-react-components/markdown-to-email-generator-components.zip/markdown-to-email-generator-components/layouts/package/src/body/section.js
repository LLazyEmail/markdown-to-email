module.exports = `<Section>{content}</Section>`;

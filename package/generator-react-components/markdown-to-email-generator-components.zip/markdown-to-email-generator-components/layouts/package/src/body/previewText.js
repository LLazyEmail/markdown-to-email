module.exports = `<PreviewText>{content}</PreviewText>`;

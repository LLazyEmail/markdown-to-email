import * as body from './body/';
import * as misc from './misc/';
import * as typography from './typography/';

export default {
    body,
    misc,
    typography,
};